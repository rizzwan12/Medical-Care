from django.shortcuts import redirect,render
from.models import Doctor,Patient,Dep,Services
# Create your views here.
def index(request):
    return render(request,'index.html')
def services(request):
    Serv=Services.objects.all()
    return render(request,'services.html',{'Serv':Serv})
def home(request):
    
        return render(request,'home.html')
def About(request):
    return render(request,'about.html')
def new(request):
    return render(request,'new.html')
def contact(request):
    return render(request,'contact.html')
def department(request):
    dp=Dep.objects.all()
    return render(request,'department.html',{'dp':dp})
   
def register(request):
    mydata=Patient.objects.all()
    if(mydata!=''):
        return render(request, 'register.html',{'datas':mydata})
    else:
        return render(request, 'register.html')
def addData(request):
    if request.method=='POST':
        firstname=request.POST['firstname']
        secondname=request.POST['secondname']
        address=request.POST['address']
        mobile=request.POST['mobile']
        sex=request.POST['sex']
        age=request.POST['age']

        obj=Patient()
        obj.firstname=firstname
        obj.secondname=secondname
        obj.address=address
        obj.mobile=mobile
        obj.sex=sex
        obj.age=age
        obj.save()
        mydata=Patient.objects.all()
    return render(request, 'register.html',{'datas':mydata})    

    
def updateData(request,id):
    mydata=Patient.objects.get(id=id)
    if request.method=='POST':
       firstname=request.POST['firstname']
       secondname=request.POST['secondname']
       address=request.POST['address']
       mobile=request.POST['mobile']
       sex=request.POST['sex']
       age=request.POST['age']

    
       mydata.firstname=firstname
       mydata.secondname=secondname
       mydata.address=address
       mydata.mobile=mobile
       mydata.sex=sex
       mydata.age=age
       mydata.save()


       return redirect('register')
    return render(request,'update.html',{'r':mydata}) 
def deleteData(request,id):
    mydata=Patient.objects.get(id=id)
    mydata.delete()
    return redirect('register')
def doctors(request):
    Doctors=Doctor.objects.all()
    return render(request,'doctors.html',{'Doctors':Doctors})
    
        
     
  