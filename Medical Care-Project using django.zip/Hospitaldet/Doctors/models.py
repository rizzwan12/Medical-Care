from django.db import models

# Create your models here.
class Doctor(models.Model):
    Name=models.CharField(max_length=250)
    Department=models.CharField(max_length=1000)
    Image=models.CharField(max_length=2500)
class Dep(models.Model):
    dname=models.CharField(max_length=250)
    days=models.CharField(max_length=250)
    desc=models.CharField(max_length=2500)

class Patient(models.Model):
    firstname=models.CharField(max_length=2500)
    secondname=models.CharField(max_length=2500)
    address=models.CharField(max_length=2500)
    mobile=models.CharField(max_length=2500)
    sex=models.CharField(max_length=200)
    age=models.CharField(max_length=250)
class Services(models.Model):
    Image=models.CharField(max_length=2500)
    Name=models.CharField(max_length=250)
    description=models.CharField(max_length=2500)


