from django.urls import path
from.import views
urlpatterns=[
    path('',views.index),
    path('about.html',views.About,name='about'),
    path('services.html',views.services,name='services'),
    path('home.html',views.home,name='home'),
    path('register.html',views.register,name='register'),
    path('doctors.html',views.doctors,name='doctors'),
    path('addData',views.addData),
    path('updateData/<int:id>',views.updateData,name='updateData'),
    path('deleteData/<int:id>',views.deleteData,name='deleteData'),
    path('new.html',views.new,name='new'),
    path('contact.html',views.contact,name='contact'),
    path('department.html',views.department,name='department'),
    path('home.html',views.home,name='home')
    ]

