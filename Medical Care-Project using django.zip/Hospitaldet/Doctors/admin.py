from django.contrib import admin

# Register your models here.
from.models import Doctor,Patient,Dep,Services
admin.site.register(Doctor),
admin.site.register(Patient),
admin.site.register(Dep),
admin.site.register(Services)
